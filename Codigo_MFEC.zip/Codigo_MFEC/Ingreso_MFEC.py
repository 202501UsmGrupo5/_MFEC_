
import os
import sys
import pymysql
from PyQt5 import QtWidgets
from PyQt5 . QtWidgets import QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5 .uic import loadUi
import pymysql
from PyQt5.QtWidgets import QMainWindow, QMessageBox
from PyQt5.uic import loadUi

from Menu_Principal import MenuPrincipal  

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("Ingreso_MFEC.ui", self)
        self.connection = None

       
                                         
        self.BotonIngresar.clicked.connect(self.connect_to_database)

    def connect_to_database(self):
        host = self.IngresarLocalHost.text()
        user = self.IngresarUsuario.text()
        password = self.IngresarContrasena.text()
        if not host or not user or not password:
            QMessageBox.warning(self, "Advertencia", "Todos los campos deben estar completos.")
            return
        try:
            self.connection = pymysql.connect(
                host=host,
                user=user,
                password=password,
                database="mfec"
            )
            QMessageBox.information(self, "Éxito", "Conectado a la base de datos.")
            self.menu = MenuPrincipal(self.connection)
            self.menu.show()
            self.hide()
        except pymysql.err.OperationalError:
            QMessageBox.critical(self, "Error", "Credenciales incorrectas.")
        except Exception as e:
            QMessageBox.critical(self, "Error inesperado", str(e))

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    ventana = MainWindow()
    ventana.show()
    sys.exit(app.exec_())



