from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser, QFileDialog
from PyQt5.uic import loadUi
from PyQt5.QtGui import QTextDocument
from PyQt5.QtPrintSupport import QPrinter

class Gestion_Pedidos(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Gestion_General/Gestion_Pedidos.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()

       

        #Botones
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.BotonImprimirPedido.clicked.connect(self.visualizar_pedido)
        self.Boton_Pdf.clicked.connect(self.imprimir_pedido)

        self.Boton_Volver_Menu_GG.clicked.connect(self.volver_menu_GG)
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
      
    
    def cargar_tablas_en_combobox(self):
        self.Seleccionar_Tabla.clear()
        self.Seleccionar_Tabla.addItem("Pedido")

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if nombre_tabla != "Pedido":
            QMessageBox.warning(self, "Advertencia", "Solo se puede visualizar la tabla Pedido.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM Pedido")
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al visualizar la tabla Pedido:\n{str(e)}")

    def visualizar_pedido(self):
        pedido_id = self.Ingresar_ID_Pedido_Imprimir.text().strip()

        if not pedido_id.isdigit():
            QMessageBox.warning(self, "Advertencia", "El PedidoID debe ser un número.")
            return

        try:
            cursor = self.connection.cursor()

            cursor.execute("""
            SELECT 
            p.PedidoID, p.RutCliente, c.Nombre, c.Telefono, c.Correo, c.Direccion
            FROM Pedido p
            JOIN Cliente c ON p.RutCliente = c.Rut
            WHERE p.PedidoID = %s
            """, (int(pedido_id),))
            pedido = cursor.fetchone()

            if not pedido:
                QMessageBox.warning(self, "Error", f"No se encontró el pedido {pedido_id}.")
                return

           
            # Mostrar datos del pedido en un QTextBrowser
            columnas = ["Pedido ID", "Rut", "Nombre", "Teléfono", "Correo", "Dirección"]
            datos_pedido = "\n".join([f"{col}: {val}" for col, val in zip(columnas, pedido)])
            self.textBrowser_DatosPedido.setPlainText(datos_pedido)

            # 2. Obtener detalles de productos del pedido
            cursor.execute("""
                SELECT p.NombreProducto, dp.Cantidad, dp.PrecioUnitario,
                    dp.Cantidad * dp.PrecioUnitario AS Subtotal
                FROM DetallePedido dp
                JOIN Producto p ON dp.ProductoID = p.ProductoID
                WHERE dp.PedidoID = %s
            """, (int(pedido_id),))
            productos = cursor.fetchall()

            # Mostrar en tabla
            self.Tabla_ProductosPedido.setRowCount(len(productos))
            self.Tabla_ProductosPedido.setColumnCount(4)
            self.Tabla_ProductosPedido.setHorizontalHeaderLabels(
                ["Producto", "Cantidad", "Precio Unitario", "Subtotal"]
            )

            for i, fila in enumerate(productos):
                for j, val in enumerate(fila):
                    self.Tabla_ProductosPedido.setItem(i, j, QTableWidgetItem(str(val)))

           

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))



    def imprimir_pedido(self):
        try:
            contenido = self.textBrowser_DatosPedido.toPlainText()
            if not contenido.strip():
                QMessageBox.warning(self, "Advertencia", "No hay datos para exportar.")
                return

            doc = QTextDocument()
            doc.setPlainText(contenido)

            ruta, _ = QFileDialog.getSaveFileName(self, "Guardar como PDF", "", "PDF files (*.pdf)")
            if not ruta:
                return
            if not ruta.endswith(".pdf"):
                ruta += ".pdf"

            printer = QPrinter()
            printer.setOutputFormat(QPrinter.PdfFormat)
            printer.setOutputFileName(ruta)
            doc.print_(printer)

            QMessageBox.information(self, "Éxito", f"PDF guardado en:\n{ruta}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo exportar a PDF:\n{str(e)}")


    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_GG(self):
        from Gestion_General.Menu_GG import MenuGG
        self.menu_principal = MenuGG(self.connection)  
        self.menu_principal.show()  
        self.hide()


