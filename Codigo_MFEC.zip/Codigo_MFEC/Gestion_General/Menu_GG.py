import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.uic import loadUi



class MenuGG(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Gestion_General/Menu_GG.ui", self)
        self.connection = connection

        #Botones
        self.Boton_Gestion_Pedidos.clicked.connect(self.abrir_gestion_pedidos)
        self.Boton_Gestion_Financiera.clicked.connect(self.abrir_gestion_financiera)
        #self.Boton_Gestion_Productos.clicked.connect(self.abrir_gestion_productos)
        self.Boton_Volver_Menu_Principal.clicked.connect(self.volver_menu_principal)
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        


    def abrir_gestion_pedidos(self):
        from Gestion_General.Gestion_Pedidos import Gestion_Pedidos
        self.ventana_gestion = Gestion_Pedidos(self.connection)
        self.ventana_gestion.show()
        self.hide()

    def abrir_gestion_financiera(self):
        from Gestion_General.Gestion_Financiera import Gestion_Financiera
        self.ventana_gestion = Gestion_Financiera(self.connection)
        self.ventana_gestion.show()
        self.hide()


    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 


    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_principal(self):
        from Menu_Principal import MenuPrincipal
        self.menu_principal = MenuPrincipal(self.connection)  
        self.menu_principal.show()  
        self.hide()


    







