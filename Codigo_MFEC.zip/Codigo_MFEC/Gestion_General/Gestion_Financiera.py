from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi

class Gestion_Financiera(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Gestion_General/Gestion_Financiera.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        

        #Botones
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Boton_Obtener_Informacion.clicked.connect(self.calcular_totales)

        self.Boton_Volver_Menu_GG.clicked.connect(self.volver_menu_GG)
        self.Boton_CS.clicked.connect(self.cerrar_sesion)


        #Cargar tablas en Combo box
    def cargar_tablas_en_combobox(self):
        self.Seleccionar_Tabla.clear()
        self.Seleccionar_Tabla.addItems(["Ingreso", "Egreso"])


    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText().strip()

        if nombre_tabla not in ["Ingreso", "Egreso"]:
            QMessageBox.warning(self, "Advertencia", "Debes seleccionar 'Ingreso' o 'Egreso'.")
            return

        # Obtener fechas del QDateEdit
        fecha_inicio = self.Ingresar_Fecha_Inicio.date().toString("yyyy-MM-dd")
        fecha_fin = self.Ingresar_Fecha_Final.date().toString("yyyy-MM-dd")

        # Determinar nombre de columna de fecha según la tabla
        columna_fecha = "FechaIngreso" if nombre_tabla == "Ingreso" else "FechaEgreso"

        try:
            cursor = self.connection.cursor()
            query = f"""
            SELECT * FROM `{nombre_tabla}`
            WHERE `{columna_fecha}` BETWEEN %s AND %s
            """

            cursor.execute(query, (fecha_inicio, fecha_fin))
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al visualizar la tabla '{nombre_tabla}':\n{str(e)}")


    #Calcula Ingresos, Egresos y Utilidad entre las fechas seleccionadas
    def calcular_totales(self):
        fecha_inicio = self.Ingresar_Fecha_Inicio.date().toString("yyyy-MM-dd")
        fecha_fin = self.Ingresar_Fecha_Final.date().toString("yyyy-MM-dd")

        try:
            cursor = self.connection.cursor()

            # Total Ingresos
            cursor.execute("""
                SELECT IFNULL(SUM(Monto), 0) FROM Ingreso
                WHERE FechaIngreso BETWEEN %s AND %s
            """, (fecha_inicio, fecha_fin))
            total_ingresos = cursor.fetchone()[0]

            # Egresos por tipo
            cursor.execute("""
                SELECT 
                    IFNULL(SUM(GastoEnvio), 0), 
                    IFNULL(SUM(GastoMateriales), 0), 
                    IFNULL(SUM(GastoEmpaque), 0)
                FROM Egreso
                WHERE FechaEgreso BETWEEN %s AND %s
            """, (fecha_inicio, fecha_fin))
            gasto_envio, gasto_materiales, gasto_empaque = cursor.fetchone()

            total_egresos = gasto_envio + gasto_materiales + gasto_empaque
            utilidad = total_ingresos - total_egresos

            resumen = (
                f"RESUMEN FINANCIERO ENTRE {fecha_inicio} Y {fecha_fin}:\n\n"
                f"     Ingresos Totales:       ${total_ingresos:,.2f}\n\n"
                f"     Egresos:\n"
                f"     Gasto Envío:          ${gasto_envio:,.2f}\n"
                f"     Gasto Materiales:     ${gasto_materiales:,.2f}\n"
                f"     Gasto Empaque:        ${gasto_empaque:,.2f}\n"
                f"     Total Egresos:        ${total_egresos:,.2f}\n\n"
                f" Utilidad Neta:          ${utilidad:,.2f}"
            )

            self.textBrowser_ResumenFinanciero.setPlainText(resumen)

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al calcular totales:\n{str(e)}")

    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_GG(self):
        from Gestion_General.Menu_GG import MenuGG
        self.menu_principal = MenuGG(self.connection)  
        self.menu_principal.show()  
        self.hide()





