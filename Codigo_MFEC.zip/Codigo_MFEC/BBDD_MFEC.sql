CREATE DATABASE IF NOT EXISTS MFEC;
USE MFEC;
#=======================================================================
#CREACIÓN DE TABLAS
CREATE TABLE Cliente (
	Rut INT NOT NULL PRIMARY KEY,
    Nombre VARCHAR(100),
    Telefono VARCHAR(20),
    Direccion VARCHAR(100),
    Correo VARCHAR(100));
    
CREATE TABLE Producto (
	ProductoID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    NombreProducto VARCHAR(100));
    
CREATE TABLE DetallePedido (
	DetallePedidoID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    ProductoID INT, #FK
    PedidoID INT, #FK
    Cantidad INT,
    PrecioUnitario DECIMAL(15,2),
    Descripcion VARCHAR(1000));
    
CREATE TABLE Pedido (
	PedidoID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    RutCliente INT, #FK
    FechaPedido DATE,
    FechaEntrega DATE,
    TipoPago VARCHAR(30),
	EstadoPedido VARCHAR(50),
    Monto DECIMAL(15,2));
    
CREATE TABLE Ingreso (
	IngresoID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    PedidoID INT, #FK
    FechaIngreso DATE,
    Monto DECIMAL(15,2),
    MetodoPago VARCHAR(30));
    
CREATE TABLE Egreso (
	EgresoID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    PedidoID INT, #FK
    GastoEnvio DECIMAL(15,2),
    GastoMateriales DECIMAL(15,2),
    GastoEmpaque DECIMAL(15,2),
    FechaEgreso DATE);
    
#=======================================================================
#AGREGAR FK

#Cliente(PK) - Pedido(FK)
ALTER TABLE Pedido
ADD CONSTRAINT FOREIGN KEY (RutCliente)
REFERENCES Cliente(Rut);

#Pedido(PK) - DetallePedido (FK)
ALTER TABLE DetallePedido
ADD CONSTRAINT FOREIGN KEY (ProductoID)
REFERENCES Producto(ProductoID);

#Pedido (PK) - DetallePedido(FK)
ALTER TABLE DetallePedido
ADD CONSTRAINT FOREIGN KEY (PedidoID)
REFERENCES Pedido(PedidoID);

#Pedido (PK) - Ingreso(FK)
ALTER TABLE Ingreso
ADD CONSTRAINT FOREIGN KEY (PedidoID)
REFERENCES Pedido(PedidoID);

#Pedido (PK) - Egreso(FK)
ALTER TABLE Egreso
ADD CONSTRAINT FOREIGN KEY (PedidoID)
REFERENCES Pedido(PedidoID); 