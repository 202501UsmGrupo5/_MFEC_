from PyQt5.QtWidgets import QMainWindow, QMessageBox
from PyQt5.uic import loadUi

# from Gestion_General.Menu_GG import MenuGG  # Si existe
from Operaciones_CRUD.Menu_CRUD import MenuCRUD
from Gestion_General.Menu_GG import MenuGG

class MenuPrincipal(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Menu_Principal.ui", self)
        self.connection = connection
        #Botones
        self.Boton_CRUD.clicked.connect(self.abrir_crud)
        self.Boton_GG.clicked.connect(self.abrir_gestion_general)
        self.Boton_CS.clicked.connect(self.cerrar_sesion)

    def abrir_crud(self):
        self.ventana_crud = MenuCRUD(self.connection)
        self.ventana_crud.show()
        self.hide()

    def abrir_gestion_general(self):
        self.ventana_crud = MenuGG(self.connection)
        self.ventana_crud.show()
        self.hide()


    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()
