from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi

class CRUD_Producto(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/CRUD_Producto.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        self.accion_actual = "Agregar" #Acción predeterminada

        #Conectar Botones:
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Page_Agregar.clicked.connect(lambda: self.cambiar_pagina(self.P_AgregarProducto))
        self.Page_Modificar.clicked.connect(lambda: self.cambiar_pagina(self.P_ModificarProducto))
        self.Page_Eliminar.clicked.connect(lambda: self.cambiar_pagina(self.P_EliminarProducto))

        #Botones CRUD Producto
        self.BotonAgregarProducto.clicked.connect(self.agregar)
        self.BotonModificarProducto.clicked.connect(self.modificar)
        self.BotonEliminarProducto.clicked.connect(self.eliminar)

        #Botones Cerrar sesión y Volver CRUD
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_CRUD.clicked.connect(self.volver_menu_CRUD)

     

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if not nombre_tabla:
            print("No se seleccionó ninguna tabla.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM `{nombre_tabla}`")  # Las comillas invertidas protegen nombres con caracteres especiales
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]  # Nombres de columnas

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            print(f"Error al visualizar la tabla '{nombre_tabla}':", e)

    def cargar_tablas_en_combobox(self):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]
            self.Seleccionar_Tabla.addItems(tablas)
        except Exception as e:
            print("Error al cargar las tablas:", e)

    
    def cambiar_pagina(self, widget_destino):
        self.stackedWidget.setCurrentWidget(widget_destino)

    #=========================================================================
    #OperacionesCRUD
    
    def agregar(self):
        NombreProducto = self.IngresarNombreProductoAgregar.text()

        if not NombreProducto:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un Nombre.")
            return
        
       

        try:
            cursor = self.connection.cursor()
            cursor.execute("INSERT INTO PRODUCTO (NombreProducto) VALUES (%s)", (NombreProducto,))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Producto agregado correctamente.")
            self.visualizar_tabla()
            self.IngresarNombreProductoAgregar.clear()
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def modificar(self):
        ProductoID = self.Ingresar_ID_Producto_Mod.text()
        NombreNuevo = self.Ingresar_Nombre_Producto_Mod.text()

        if not ProductoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un ProductoID.")
            return

        if not ProductoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El ProductoID ingresado contiene carácteres no numéricos.")
            return

        ProductoID = int(ProductoID)

        try:
            cursor = self.connection.cursor()

            # Verificar si el producto existe y obtener el nombre actual
            cursor.execute("SELECT NombreProducto FROM Producto WHERE ProductoID = %s", (ProductoID,))
            resultado = cursor.fetchone()

            if not resultado:
                QMessageBox.warning(self, "Advertencia", f"No se encontró ningún producto con el ID {ProductoID}.")
                return

            nombre_actual = resultado[0]

            # Si el campo de nombre está vacío, se conserva el nombre actual
            NombreProducto = NombreNuevo if NombreNuevo else nombre_actual

            # Realizar la actualización
            cursor.execute("""
                UPDATE Producto
                SET NombreProducto = %s
                WHERE ProductoID = %s
            """, (NombreProducto, ProductoID))
            self.connection.commit()

            QMessageBox.information(self, "Éxito", f"Producto con ID {ProductoID} modificado correctamente.")
            self.visualizar_tabla()

            # Limpiar campos
            self.Ingresar_ID_Producto_Mod.clear()
            self.Ingresar_Nombre_Producto_Mod.clear()

    

            

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo modificar el Producto.\n{str(e)}")


        
    def eliminar(self):
        ProductoID = self.Ingresar_ID_Producto_Eliminar.text()
        if not ProductoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un ProductoID.")
            return
        if not ProductoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El ProductoID ingresado contiene carácteres no numéricos.")
            return
        ProductoID = int(ProductoID)
        
        try:
            cursor = self.connection.cursor()
            # Verificar si el Producto existe
            cursor.execute("SELECT * FROM PRODCUTO WHERE ProductoID = %s", (ProductoID,))
            producto_existente = cursor.fetchone()

            if not producto_existente:
                QMessageBox.warning(self, "Advertencia", f"No se encontró ningún ProductoID {ProductoID}.")
                return
        # Confirmar eliminación
            confirm = QMessageBox.question(
                self, "Confirmar eliminación",
                f"¿Estás seguro que deseas eliminar al ProductoID {ProductoID}?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return
            
            cursor.execute("DELETE FROM PRODUCTO WHERE ProductoID = %s",(ProductoID))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Producto eliminado correctamente.")
            self.visualizar_tabla()
            self.Ingresar_ID_Producto_Eliminar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))



    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 