import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.uic import loadUi



class MenuCRUD(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/Menu_CRUD.ui", self)
        self.connection = connection

        #Botones
        self.Boton_Cliente.clicked.connect(self.abrir_crud_cliente)
        self.Boton_Producto.clicked.connect(self.abrir_crud_producto)
        self.Boton_Pedido.clicked.connect(self.abrir_crud_pedido)
        self.Boton_DetallePedido.clicked.connect(self.abrir_crud_detallepedido)
        self.Boton_Egreso.clicked.connect(self.abrir_crud_egreso)
        self.Boton_Ingreso.clicked.connect(self.abrir_crud_ingreso)

        #Botones Cerrar sesión y Volver Menú Principal
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_Principal.clicked.connect(self.volver_menu_principal)


    def abrir_crud_cliente(self):
        from Operaciones_CRUD.CRUD_Cliente import CRUD_Cliente
        self.ventana_cliente = CRUD_Cliente(self.connection)
        self.ventana_cliente.show()
        self.hide()

    def abrir_crud_producto(self):
        from Operaciones_CRUD.CRUD_Producto import CRUD_Producto
        self.ventana_cliente = CRUD_Producto(self.connection)
        self.ventana_cliente.show()
        self.hide()

    def abrir_crud_pedido(self):
        from Operaciones_CRUD.CRUD_Pedido import CRUD_Pedido
        self.ventana_cliente = CRUD_Pedido(self.connection)
        self.ventana_cliente.show()
        self.hide()

    def abrir_crud_detallepedido(self):
        from Operaciones_CRUD.CRUD_DetallePedido import CRUD_DetallePedido
        self.ventana_cliente = CRUD_DetallePedido(self.connection)
        self.ventana_cliente.show()
        self.hide()

    def abrir_crud_egreso(self):
        from Operaciones_CRUD.CRUD_Egreso import CRUD_Egreso
        self.ventana_cliente = CRUD_Egreso(self.connection)
        self.ventana_cliente.show()
        self.hide()

    def abrir_crud_ingreso(self):
        from Operaciones_CRUD.CRUD_Ingreso import CRUD_Ingreso
        self.ventana_cliente = CRUD_Ingreso(self.connection)
        self.ventana_cliente.show()
        self.hide()


    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_principal(self):
        from Menu_Principal import MenuPrincipal
        self.menu_principal = MenuPrincipal(self.connection)  
        self.menu_principal.show()  
        self.hide() 


    







