from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi

class CRUD_Pedido(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/CRUD_Pedido.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        self.accion_actual = "Agregar" #Acción predeterminada

        #Conectar Botones:
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Page_Agregar.clicked.connect(lambda: self.cambiar_pagina(self.P_Agregar))
        self.Page_Modificar.clicked.connect(lambda: self.cambiar_pagina(self.P_Modificar))
        self.Page_Eliminar.clicked.connect(lambda: self.cambiar_pagina(self.P_Eliminar))

        #Botones CRUD Cliente
        self.BotonAgregar.clicked.connect(self.agregar)
        self.BotonModificar.clicked.connect(self.modificar)
        self.BotonEliminar.clicked.connect(self.eliminar)

        #Botones Cerrar sesión y Volver CRUD
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_CRUD.clicked.connect(self.volver_menu_CRUD)

     

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if not nombre_tabla:
            print("No se seleccionó ninguna tabla.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM `{nombre_tabla}`")  # Las comillas invertidas protegen nombres con caracteres especiales
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]  # Nombres de columnas

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            print(f"Error al visualizar la tabla '{nombre_tabla}':", e)

    def cargar_tablas_en_combobox(self):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]
            self.Seleccionar_Tabla.addItems(tablas)
        except Exception as e:
            print("Error al cargar las tablas:", e)

    
    def cambiar_pagina(self, widget_destino):
        self.stackedWidget.setCurrentWidget(widget_destino)

    #=========================================================================
    #OperacionesCRUD

    def agregar(self):
        RutCliente = self.IngresarRutClienteAgregar.text()
        FechaPedido = self.IngresarFechaPedidoAgregar.text()
        FechaEntrega = self.IngresarFechaEntregaPedidoAgregar.text()
        TipoPago = self.IngresarTipoPagoPedidoAgregar.text()
        EstadoPedido = self.IngresarEstadoPedidoAgregar.text()
        Monto = self.IngresarMontoPedidoAgregar.text()

        if not RutCliente:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar el RUT del Cliente.")
            return
        if not RutCliente.isdigit():
            QMessageBox.warning(self, "Advertencia", "El RUT del Cliente ingresado contiene carácteres no numéricos.")
            return
        
        

        try:
            Monto = float(Monto)
        except ValueError:
            QMessageBox.warning(self, "Advertencia", "El monto debe ser un número válido.")
            return
        

        
    
        RutCliente = int(RutCliente)

        # Verificar si existe en la tabla Cliente
        cursor = self.connection.cursor()
        cursor.execute("""SELECT * FROM Cliente WHERE Rut = %s""", (RutCliente))
        cliente_existente = cursor.fetchone()

        if not cliente_existente:
            QMessageBox.warning(self, "Error", f"El RUT {RutCliente} no está registrado como cliente.")
            return

        
        

        try:
            cursor = self.connection.cursor()
            cursor.execute("""INSERT INTO PEDIDO (RutCliente,FechaPedido, FechaEntrega, TipoPago, EstadoPedido, Monto) VALUES (%s, %s, %s, %s, %s, %s)""", (RutCliente, FechaPedido, FechaEntrega, TipoPago, EstadoPedido, Monto))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Pedido agregado correctamente.")
            self.visualizar_tabla()

            self.IngresarRutClienteAgregar.clear()
            self.IngresarFechaPedidoAgregar.clear()
            self.IngresarFechaEntregaPedidoAgregar.clear()
            self.IngresarTipoPagoPedidoAgregar.clear()
            self.IngresarEstadoPedidoAgregar.clear()
            self.IngresarMontoPedidoAgregar.clear()
           


        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def modificar(self):
        PedidoID = self.Ingresar_ID_Pedido_Mod.text()

        if not PedidoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un PedidoID.")
            return
    
        if not PedidoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El PedidoID ingresado contiene caracteres no numéricos.")
            return
    
        PedidoID = int(PedidoID)

        try:
            cursor = self.connection.cursor()

            # Obtener datos actuales del pedido
            cursor.execute("""
                SELECT RutCliente, FechaPedido, FechaEntrega, TipoPago, EstadoPedido, Monto 
                FROM PEDIDO 
                WHERE PedidoID = %s
            """, (PedidoID,))
            resultado = cursor.fetchone()

            if not resultado:
                QMessageBox.warning(self, "Advertencia", f"No se encontró ningún Pedido con el ID {PedidoID}.")
                return

            # Extraer valores actuales
            RutCliente_actual, FechaPedido_actual, FechaEntrega_actual, TipoPago_actual, EstadoPedido_actual, Monto_actual = resultado

            # Obtener lo ingresado por el usuario
            RutCliente_nuevo = self.Ingresar_Rut_Cliente_Mod.text()
            FechaPedido_nuevo = self.Ingresar_Fecha_Pedido_Mod.text()
            FechaEntrega_nueva = self.Ingresar_Fecha_Entrega_Mod.text()
            TipoPago_nuevo = self.Ingresar_Tipo_Pago_Mod.text()
            EstadoPedido_nuevo = self.Ingresar_Estado_Pedido_Mod.text()
            Monto_nuevo = self.Ingresar_Monto_Pedido_Mod.text()

            # Validar y usar valores antiguos si el campo está vacío
            RutCliente_nuevo = int(RutCliente_nuevo) if RutCliente_nuevo.isdigit() else RutCliente_actual
            FechaPedido_nuevo = FechaPedido_nuevo if FechaPedido_nuevo else FechaPedido_actual
            FechaEntrega_nueva = FechaEntrega_nueva if FechaEntrega_nueva else FechaEntrega_actual
            TipoPago_nuevo = TipoPago_nuevo if TipoPago_nuevo else TipoPago_actual
            EstadoPedido_nuevo = EstadoPedido_nuevo if EstadoPedido_nuevo else EstadoPedido_actual

            if Monto_nuevo.strip() == "":
                Monto_nuevo = Monto_actual
            else:
                try:
                    Monto_nuevo = float(Monto_nuevo)
                except ValueError:
                    QMessageBox.warning(self, "Advertencia", "El monto debe ser un número válido.")
                    return

            # Verificar si existe el cliente
            cursor.execute("SELECT * FROM Cliente WHERE Rut = %s", (RutCliente_nuevo,))
            cliente_existente = cursor.fetchone()

            if not cliente_existente:
                QMessageBox.warning(self, "Error", f"El RUT {RutCliente_nuevo} no está registrado como cliente.")
                return

            # Ejecutar el UPDATE
            cursor.execute("""
                UPDATE PEDIDO
                SET 
                    RutCliente = %s,
                    FechaPedido = %s,
                    FechaEntrega = %s,
                    TipoPago = %s,
                    EstadoPedido = %s,
                    Monto = %s
                WHERE PedidoID = %s
            """, (RutCliente_nuevo, FechaPedido_nuevo, FechaEntrega_nueva, TipoPago_nuevo, EstadoPedido_nuevo, Monto_nuevo, PedidoID))

            self.connection.commit()

            QMessageBox.information(self, "Éxito", f"Pedido con ID {PedidoID} modificado correctamente.")
            self.visualizar_tabla()

            # Limpiar campos
            self.Ingresar_ID_Pedido_Mod.clear()
            self.Ingresar_Rut_Cliente_Mod.clear()
            self.Ingresar_Fecha_Pedido_Mod.clear()
            self.Ingresar_Fecha_Entrega_Mod.clear()
            self.Ingresar_Tipo_Pago_Mod.clear()
            self.Ingresar_Estado_Pedido_Mod.clear()
            self.Ingresar_Monto_Pedido_Mod.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo modificar el Pedido.\n{str(e)}")

        

        
    def eliminar(self):
        PedidoID = self.Ingresar_ID_Pedido_Eliminar.text()
        if not PedidoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un PedidoID.")
            return
        if not PedidoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El PedidoID ingresado contiene carácteres no numéricos.")
            return
        PedidoID = int(PedidoID)
        
        try:
            cursor = self.connection.cursor()
            # Verificar si el pedido existe
            cursor.execute("SELECT * FROM PEDIDO WHERE PedidoID = %s", (PedidoID,))
            pedido_existente = cursor.fetchone()

            if not pedido_existente:
                QMessageBox.warning(self, "Advertencia", f"No se encontró ningún Pedido con el ID {PedidoID}.")
                return
        # Confirmar eliminación
            confirm = QMessageBox.question(
                self, "Confirmar eliminación",
                f"¿Estás seguro que deseas eliminar al PedidoID {PedidoID}?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return
            
            cursor.execute("DELETE FROM PEDIDO WHERE PedidoID = %s",(PedidoID))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Pedido eliminado correctamente.")
            self.visualizar_tabla()
            self.Ingresar_ID_Pedido_Eliminar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 