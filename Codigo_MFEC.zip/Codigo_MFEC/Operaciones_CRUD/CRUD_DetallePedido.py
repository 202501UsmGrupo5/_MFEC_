from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi

class CRUD_DetallePedido(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/CRUD_DetallePedido.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        self.accion_actual = "Agregar" #Acción predeterminada

        #Conectar Botones:
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Page_Agregar.clicked.connect(lambda: self.cambiar_pagina(self.P_Agregar))
        self.Page_Modificar.clicked.connect(lambda: self.cambiar_pagina(self.P_Modificar))
        self.Page_Eliminar.clicked.connect(lambda: self.cambiar_pagina(self.P_Eliminar))

        #Botones CRUD Cliente
        self.BotonAgregar.clicked.connect(self.agregar)
        self.BotonModificar.clicked.connect(self.modificar)
        self.BotonEliminar.clicked.connect(self.eliminar)

        #Botones Cerrar sesión y Volver CRUD
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_CRUD.clicked.connect(self.volver_menu_CRUD)

     

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if not nombre_tabla:
            print("No se seleccionó ninguna tabla.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM `{nombre_tabla}`")  # Las comillas invertidas protegen nombres con caracteres especiales
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]  # Nombres de columnas

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            print(f"Error al visualizar la tabla '{nombre_tabla}':", e)

    def cargar_tablas_en_combobox(self):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]
            self.Seleccionar_Tabla.addItems(tablas)
        except Exception as e:
            print("Error al cargar las tablas:", e)

    
    def cambiar_pagina(self, widget_destino):
        self.stackedWidget.setCurrentWidget(widget_destino)

    #=========================================================================
    #OperacionesCRUD

    def agregar(self):
        ProductoID = self.IngresarRutClienteAgregar.text()
        PedidoID = self.IngresarFechaPedidoAgregar.text()
        Cantidad = self.IngresarFechaEntregaPedidoAgregar.text()
        PrecioUnitario = self.IngresarTipoPagoPedidoAgregar.text()
        Descripcion = self.IngresarEstadoPedidoAgregar.text()

        if not ProductoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar el ProductoID.")
            return
        
        if not PedidoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar el PedidoID.")
            return
        
        if not Cantidad:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar la cantidad de producto.")
            return

        if not (ProductoID.isdigit() and PedidoID.isdigit() and Cantidad.isdigit()):
            QMessageBox.warning(self, "Advertencia", "ProductoID, PedidoID y Cantidad deben ser números enteros.")
            return
        
        # Verificar si existe en la tabla producto
        cursor = self.connection.cursor()
        cursor.execute("""SELECT * FROM PRODUCTO WHERE ProductoID = %s""", (ProductoID))
        cliente_existente = cursor.fetchone()
        if not cliente_existente:
            QMessageBox.warning(self, "Error", f"El ProductoID {ProductoID} no está registrado como Producto.")
            return
        
        # Verificar si existe en la tabla pedido
        cursor = self.connection.cursor()
        cursor.execute("""SELECT * FROM PEDIDO WHERE PedidoID = %s""", (PedidoID))
        cliente_existente = cursor.fetchone()
        if not cliente_existente:
            QMessageBox.warning(self, "Error", f"El PedidoID {PedidoID} no está registrado como Pedido.")
            return
        

        
        try:
            PrecioUnitario = float(PrecioUnitario)
        except ValueError:
            QMessageBox.warning(self, "Advertencia", "Precio unitario debe ser un número decimal.")
            return
        
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT INTO DetallePedido (ProductoID, PedidoID, Cantidad, PrecioUnitario, Descripcion)
                VALUES (%s, %s, %s, %s, %s)
            """, (int(ProductoID), int(PedidoID), int(Cantidad), PrecioUnitario, Descripcion))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "DetallePedido agregado correctamente.")
            self.visualizar_tabla()

            self.IngresarRutClienteAgregar.clear()
            self.IngresarFechaPedidoAgregar.clear()
            self.IngresarFechaEntregaPedidoAgregar.clear()
            self.IngresarTipoPagoPedidoAgregar.clear()
            self.IngresarEstadoPedidoAgregar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def modificar(self):
        DetallePedidoID = self.Ingresar_ID_Pedido_Mod.text()
        if not DetallePedidoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "Debe ingresar un DetallePedidoID válido.")
            return

        cursor = self.connection.cursor()
        cursor.execute("""
            SELECT ProductoID, PedidoID, Cantidad, PrecioUnitario, Descripcion
            FROM DetallePedido
            WHERE DetallePedidoID = %s
        """, (int(DetallePedidoID),))
        actual = cursor.fetchone()

        if not actual:
            QMessageBox.warning(self, "Error", "No se encontró ese DetallePedido.")
            return

        prod_nuevo = self.Ingresar_Rut_Cliente_Mod.text()
        pedido_nuevo = self.Ingresar_Fecha_Pedido_Mod.text()
        cant_nueva = self.Ingresar_Fecha_Entrega_Mod.text()
        precio_nuevo = self.Ingresar_Tipo_Pago_Mod.text()
        desc_nueva = self.Ingresar_Estado_Pedido_Mod.text()

        try:
            ProductoID = int(prod_nuevo) if prod_nuevo.strip().isdigit() else actual[0]
            PedidoID = int(pedido_nuevo) if pedido_nuevo.strip().isdigit() else actual[1]
            Cantidad = int(cant_nueva) if cant_nueva.strip().isdigit() else actual[2]
            PrecioUnitario = float(precio_nuevo) if precio_nuevo.strip() else actual[3]
        except ValueError:
            QMessageBox.warning(self, "Advertencia", "Verifique que los campos tengan el tipo correcto; Números enteros: ProductoID, PedidoID, Cantidad; Número decimal: Precio unitario")
            return

        Descripcion = desc_nueva if desc_nueva else actual[4]

        try:
            cursor.execute("""
                UPDATE DetallePedido
                SET ProductoID = %s, PedidoID = %s, Cantidad = %s, PrecioUnitario = %s, Descripcion = %s
                WHERE DetallePedidoID = %s
            """, (ProductoID, PedidoID, Cantidad, PrecioUnitario, Descripcion, int(DetallePedidoID)))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Registro modificado correctamente.")
            self.visualizar_tabla()

            self.Ingresar_ID_Pedido_Mod.clear()
            self.Ingresar_Rut_Cliente_Mod.clear()
            self.Ingresar_Fecha_Pedido_Mod.clear()
            self.Ingresar_Fecha_Entrega_Mod.clear()
            self.Ingresar_Tipo_Pago_Mod.clear()
            self.Ingresar_Estado_Pedido_Mod.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

        

        
    def eliminar(self):
        DetallePedidoID = self.Ingresar_ID_Pedido_Eliminar.text()
        if not DetallePedidoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El DetallePedidoID ingresado contiene carácteres no numéricos.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM DetallePedido WHERE DetallePedidoID = %s", (int(DetallePedidoID),))
            existe = cursor.fetchone()
            if not existe:
                QMessageBox.warning(self, "Advertencia", "No se encontró el DetallePedidoID.")
                return

            confirm = QMessageBox.question(
                self, "Confirmar eliminación",
                f"¿Estás seguro de eliminar el DetallePedido {DetallePedidoID}?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return

            cursor.execute("DELETE FROM DetallePedido WHERE DetallePedidoID = %s", (int(DetallePedidoID),))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "DetallePedido eliminado.")
            self.visualizar_tabla()
            self.Ingresar_ID_Pedido_Eliminar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 