from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi

class CRUD_Cliente(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/CRUD_Cliente.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        self.accion_actual = "Agregar" #Acción predeterminada

        #Conectar Botones:
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Page_Agregar.clicked.connect(lambda: self.cambiar_pagina(self.P_AgregarCliente))
        self.Page_Modificar.clicked.connect(lambda: self.cambiar_pagina(self.P_ModificarCliente))
        self.Page_Eliminar.clicked.connect(lambda: self.cambiar_pagina(self.P_EliminarCliente))

        #Botones CRUD Cliente
        self.BotonAgregarCliente.clicked.connect(self.agregar_cliente)
        self.BotonModificarCliente.clicked.connect(self.modificar_cliente)
        self.BotonEliminarCliente.clicked.connect(self.eliminar_cliente)


         #Botones Cerrar sesión y Volver CRUD
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_CRUD.clicked.connect(self.volver_menu_CRUD)

     

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if not nombre_tabla:
            print("No se seleccionó ninguna tabla.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM `{nombre_tabla}`")  # Las comillas invertidas protegen nombres con caracteres especiales
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]  # Nombres de columnas

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            print(f"Error al visualizar la tabla '{nombre_tabla}':", e)

    def cargar_tablas_en_combobox(self):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]
            self.Seleccionar_Tabla.addItems(tablas)
        except Exception as e:
            print("Error al cargar las tablas:", e)

    
    def cambiar_pagina(self, widget_destino):
        self.stackedWidget.setCurrentWidget(widget_destino)

    #=========================================================================
    #OperacionesCRUD

    def agregar_cliente(self):
        Rut = self.IngresarRutClienteAgregar.text()
        Nombre = self.IngresarNombreClienteAgregar.text()
        Telefono = self.IngresarTelefonoClienteAgregar.text()
        Direccion = self.IngresarDireccionClienteAgregar.text()
        Correo = self.IngresarCorreoClienteAgregar.text()

        if not Rut:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un RUT.")
            return
        if not Rut.isdigit():
            QMessageBox.warning(self, "Advertencia", "El RUT ingresado contiene carácteres no numéricos.")
            return
        
        Rut = int(Rut)

        try:
            cursor = self.connection.cursor()
            cursor.execute("INSERT INTO CLIENTE VALUES (%s, %s, %s, %s, %s)", (Rut, Nombre, Telefono, Direccion, Correo))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Cliente agregado correctamente.")
            self.visualizar_tabla()
            self.IngresarRutClienteAgregar.clear()
            self.IngresarNombreClienteAgregar.clear()
            self.IngresarTelefonoClienteAgregar.clear()
            self.IngresarDireccionClienteAgregar.clear()
            self.IngresarCorreoClienteAgregar.clear()


        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def modificar_cliente(self):
        Rut = self.Ingresar_Rut_Cliente_Mod.text()

        if not Rut:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un RUT.")
            return
    
        if not Rut.isdigit():
            QMessageBox.warning(self, "Advertencia", "El RUT ingresado contiene caracteres no numéricos.")
            return
    
        Rut = int(Rut)

        try:
            cursor = self.connection.cursor()

            # Obtener datos actuales del cliente
            cursor.execute("SELECT Nombre, Telefono, Direccion, Correo FROM Cliente WHERE Rut = %s", (Rut,))
            resultado = cursor.fetchone()

            if not resultado:
                QMessageBox.warning(self, "Advertencia", f"No se encontró ningún cliente con el RUT {Rut}.")
                return

            # Extraer valores actuales
            nombre_actual, telefono_actual, direccion_actual, correo_actual = resultado

            # Obtener lo ingresado por el usuario
            nombre_nuevo = self.Ingresar_Nombre_Mod.text()
            telefono_nuevo = self.Ingresar_Telefono_Cliente_Mod.text()
            direccion_nueva = self.Ingresar_Direccion_Cliente_Mod.text()
            correo_nuevo = self.Ingresar_Correo_Cliente_Mod.text()

            # Si el campo está vacío, se usa el valor anterior
            nombre_final = nombre_nuevo if nombre_nuevo else nombre_actual
            telefono_final = telefono_nuevo if telefono_nuevo else telefono_actual
            direccion_final = direccion_nueva if direccion_nueva else direccion_actual
            correo_final = correo_nuevo if correo_nuevo else correo_actual

            # Ejecutar UPDATE
            cursor.execute("""
                UPDATE Cliente
                SET Nombre = %s,
                Telefono = %s,
                Direccion = %s,
                Correo = %s
                WHERE Rut = %s
            """, (nombre_final, telefono_final, direccion_final, correo_final, Rut))
        
            self.connection.commit()

            QMessageBox.information(self, "Éxito", f"Cliente con RUT {Rut} modificado correctamente.")
            self.visualizar_tabla()

            # Limpiar campos
            self.Ingresar_Rut_Cliente_Mod.clear()
            self.Ingresar_Nombre_Mod.clear()
            self.Ingresar_Telefono_Cliente_Mod.clear()
            self.Ingresar_Direccion_Cliente_Mod.clear()
            self.Ingresar_Correo_Cliente_Mod.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo modificar el cliente.\n{str(e)}")



        
    def eliminar_cliente(self):
        Rut = self.Ingresar_Rut_Cliente_Eliminar.text()
        if not Rut:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un RUT.")
            return
        if not Rut.isdigit():
            QMessageBox.warning(self, "Advertencia", "El RUT ingresado contiene carácteres no numéricos.")
            return
        Rut = int(Rut)
        
        try:
            cursor = self.connection.cursor()
            # Verificar si el cliente existe
            cursor.execute("SELECT * FROM Cliente WHERE Rut = %s", (Rut,))
            cliente_existente = cursor.fetchone()

            if not cliente_existente:
                QMessageBox.warning(self, "Advertencia", f"No se encontró ningún cliente con el RUT {Rut}.")
                return



        # Confirmar eliminación
            confirm = QMessageBox.question(
                self, "Confirmar eliminación",
                f"¿Estás seguro que deseas eliminar al cliente ID {Rut}?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return
            
            cursor.execute("DELETE FROM Cliente WHERE Rut = %s",(Rut))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Cliente eliminado correctamente.")
            self.visualizar_tabla()
            self.Ingresar_Rut_Cliente_Eliminar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 