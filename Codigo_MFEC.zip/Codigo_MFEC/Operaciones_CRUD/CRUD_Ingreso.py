from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi


class CRUD_Ingreso(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/CRUD_Ingreso.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        self.accion_actual = "Agregar" #Acción predeterminada

        #Conectar Botones:
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Page_Agregar.clicked.connect(lambda: self.cambiar_pagina(self.P_Agregar))
        self.Page_Modificar.clicked.connect(lambda: self.cambiar_pagina(self.P_Modificar))
        self.Page_Eliminar.clicked.connect(lambda: self.cambiar_pagina(self.P_Eliminar))

        #Botones CRUD Cliente
        self.BotonAgregar.clicked.connect(self.agregar)
        self.BotonModificar.clicked.connect(self.modificar)
        self.BotonEliminar.clicked.connect(self.eliminar)

        #Botones Cerrar sesión y Volver CRUD
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_CRUD.clicked.connect(self.volver_menu_CRUD)

     

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if not nombre_tabla:
            print("No se seleccionó ninguna tabla.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM `{nombre_tabla}`")  # Las comillas invertidas protegen nombres con caracteres especiales
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]  # Nombres de columnas

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            print(f"Error al visualizar la tabla '{nombre_tabla}':", e)

    def cargar_tablas_en_combobox(self):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]
            self.Seleccionar_Tabla.addItems(tablas)
        except Exception as e:
            print("Error al cargar las tablas:", e)

    
    def cambiar_pagina(self, widget_destino):
        self.stackedWidget.setCurrentWidget(widget_destino)

    #=========================================================================
    #OperacionesCRUD

    def agregar(self):
        PedidoID = self.IngresarIDPedidoIngresoAgregar.text()
        FechaIngreso = self.IngresarFechaIngresoAgregar.text()
        Monto = self.IngresarMontoIngresoAgregar.text()
        MetodoPago = self.IngresarMetodoPagoIngresoAgregar.text()
        
        if not PedidoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar el PedidoID.")
            return
        
        if not PedidoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El PedidoID ingresado contiene carácteres no numéricos.")
            return
        PedidoID = int(PedidoID)
        
        # Verificar si existe en la tabla pedido
        cursor = self.connection.cursor()
        cursor.execute("""SELECT * FROM PEDIDO WHERE PedidoID = %s""", (PedidoID))
        cliente_existente = cursor.fetchone()
        if not cliente_existente:
            QMessageBox.warning(self, "Error", f"El PedidoID {PedidoID} no está registrado como Pedido.")
            return
        
        try:
            Monto = int(Monto)
        except ValueError:
            QMessageBox.warning(self, "Advertencia", "Monto debe ser un número válido.")
            return
        
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                INSERT INTO INGRESO (PedidoID, FechaIngreso, Monto, MetodoPago)
                VALUES (%s, %s, %s, %s)
            """, (int(PedidoID), FechaIngreso, Monto, MetodoPago))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Ingreso agregado correctamente.")
            self.visualizar_tabla()

            self.IngresarIDPedidoIngresoAgregar.clear()
            self.IngresarFechaIngresoAgregar.clear()
            self.IngresarMontoIngresoAgregar.clear()
            self.IngresarMetodoPagoIngresoAgregar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def modificar(self):
        IngresoID = self.Ingresar_ID_Ingreso_Mod.text().strip()
        nuevo_pedido_id = self.Ingresar_ID_Pedido_Ingreso_Mod.text().strip()
        nueva_fecha = self.Ingresar_Fecha_Ingreso_Mod.text().strip()
        nuevo_monto = self.Ingresar_Monto_Ingreso_Mod.text().strip()
        nuevo_metodo_pago = self.Ingresar_Metodo_Pago_Ingreso_Mod.text().strip()

        if not IngresoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "Debes ingresar un ID de ingreso contiene carácteres no numéricos.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM Ingreso WHERE IngresoID = %s", (int(IngresoID),))
            ingreso_existente = cursor.fetchone()

            if not ingreso_existente:
                QMessageBox.warning(self, "Advertencia", "No existe un ingreso con ese ID.")
                return

            # Usar valores anteriores si no se ingresa alguno nuevo
            PedidoID = int(nuevo_pedido_id) if nuevo_pedido_id else ingreso_existente[1]
            FechaIngreso = nueva_fecha if nueva_fecha else ingreso_existente[2]
            Monto = float(nuevo_monto) if nuevo_monto else ingreso_existente[3]
            MetodoPago = nuevo_metodo_pago if nuevo_metodo_pago else ingreso_existente[4]

            # Verificar que el PedidoID exista en la tabla Pedido
            cursor.execute("SELECT * FROM Pedido WHERE PedidoID = %s", (PedidoID,))
            pedido_valido = cursor.fetchone()
            if not pedido_valido:
                QMessageBox.warning(self, "Advertencia", f"No existe un Pedido con ID {PedidoID}.")
                return

            # Ejecutar UPDATE
            cursor.execute("""
                UPDATE Ingreso
                SET PedidoID = %s, FechaIngreso = %s, Monto = %s, MetodoPago = %s
                WHERE IngresoID = %s
            """, (PedidoID, FechaIngreso, Monto, MetodoPago, int(IngresoID)))

            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Registro modificado correctamente.")
            self.visualizar_tabla()

            # Limpiar campos
            self.Ingresar_ID_Ingreso_Mod.clear()
            self.Ingresar_ID_Pedido_Ingreso_Mod.clear()
            self.Ingresar_Fecha_Ingreso_Mod.clear()
            self.Ingresar_Monto_Ingreso_Mod.clear()
            self.Ingresar_Metodo_Pago_Ingreso_Mod.clear()

        except ValueError:
            QMessageBox.warning(self, "Advertencia", "Monto debe ser un número válido.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al modificar ingreso:\n{e}")


        

        
    def eliminar(self):
        IngresoID = self.Ingresar_ID_Ingreso_Eliminar.text()
        if not IngresoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El IngresoID ingresado contiene carácteres no numéricos.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM INGRESO WHERE IngresoID = %s", (int(IngresoID),))
            existe = cursor.fetchone()
            if not existe:
                QMessageBox.warning(self, "Advertencia", "No se encontró el IngresoID.")
                return

            confirm = QMessageBox.question(
                self, "Confirmar eliminación",
                f"¿Estás seguro de eliminar el DetallePedido {IngresoID}?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return

            cursor.execute("DELETE FROM INGRESO WHERE IngresoID = %s", (int(IngresoID),))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Ingreso eliminado.")
            self.visualizar_tabla()
            self.Ingresar_ID_Pedido_Eliminar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 