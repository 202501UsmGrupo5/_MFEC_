from PyQt5.QtWidgets import  QApplication , QMainWindow , QDialog , QMessageBox , QTableWidgetItem , QTextBrowser
from PyQt5.uic import loadUi

print("Ventana Error")

class CRUD_Egreso(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("Operaciones_CRUD/CRUD_Egreso.ui", self)
        self.connection = connection
        self.cargar_tablas_en_combobox()
        self.accion_actual = "Agregar" #Acción predeterminada

        #Conectar Botones:
        self.Boton_Visualizar.clicked.connect(self.visualizar_tabla)
        self.Page_Agregar.clicked.connect(lambda: self.cambiar_pagina(self.P_Agregar))
        self.Page_Modificar.clicked.connect(lambda: self.cambiar_pagina(self.P_Modificar))
        self.Page_Eliminar.clicked.connect(lambda: self.cambiar_pagina(self.P_Eliminar))

        #Botones CRUD Cliente
        self.BotonAgregar.clicked.connect(self.agregar)
        self.BotonModificar.clicked.connect(self.modificar)
        self.BotonEliminar.clicked.connect(self.eliminar)

        #Botones Cerrar sesión y Volver CRUD
        self.Boton_CS.clicked.connect(self.cerrar_sesion)
        self.Boton_Volver_Menu_CRUD.clicked.connect(self.volver_menu_CRUD)

     

    def visualizar_tabla(self):
        nombre_tabla = self.Seleccionar_Tabla.currentText()
    
        if not nombre_tabla:
            print("No se seleccionó ninguna tabla.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute(f"SELECT * FROM `{nombre_tabla}`")  # Las comillas invertidas protegen nombres con caracteres especiales
            registros = cursor.fetchall()
            columnas = [desc[0] for desc in cursor.description]  # Nombres de columnas

            self.Tabla.setRowCount(len(registros))
            self.Tabla.setColumnCount(len(columnas))
            self.Tabla.setHorizontalHeaderLabels(columnas)

            for fila_idx, fila in enumerate(registros):
                for col_idx, valor in enumerate(fila):
                    self.Tabla.setItem(fila_idx, col_idx, QTableWidgetItem(str(valor)))

        except Exception as e:
            print(f"Error al visualizar la tabla '{nombre_tabla}':", e)

    def cargar_tablas_en_combobox(self):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SHOW TABLES")
            tablas = [fila[0] for fila in cursor.fetchall()]
            self.Seleccionar_Tabla.addItems(tablas)
        except Exception as e:
            print("Error al cargar las tablas:", e)

    
    def cambiar_pagina(self, widget_destino):
        self.stackedWidget.setCurrentWidget(widget_destino)

    #=========================================================================
    #OperacionesCRUD

    def agregar(self):
        PedidoID = self.IngresarIDPedidoEgresoAgregar.text().strip()
        GastoEnvio = self.IngresarGastoEnvioEgresoAgregar.text().strip()
        GastoMateriales = self.IngresarGastoMaterialesEgresoAgregar_2.text().strip()
        GastoEmpaque = self.IngresarGastoEmpaqueEgresoAgregar.text().strip()
        FechaEgreso = self.IngresarFechaEgresoAgregar.text().strip()

        if not PedidoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar el PedidoID.")
            return
        if not PedidoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El PedidoID ingresado contiene carácteres no numéricos.")
            return
        PedidoID = int(PedidoID)

        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM PEDIDO WHERE PedidoID = %s", (PedidoID,))
            if not cursor.fetchone():
                QMessageBox.warning(self, "Error", f"El PedidoID {PedidoID} no existe.")
                return

            cursor.execute("""
                INSERT INTO Egreso (PedidoID, GastoEnvio, GastoMateriales, GastoEmpaque, fechaEgreso)
                VALUES (%s, %s, %s, %s, %s)
            """, (int(PedidoID), float(GastoEnvio), float(GastoMateriales), float(GastoEmpaque), FechaEgreso))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Egreso agregado correctamente.")
            self.visualizar_tabla()

            # Limpiar campos
            self.IngresarIDPedidoEgresoAgregar.clear()
            self.IngresarFechaEgresoAgregar.clear()
            self.IngresarGastoEnvioEgresoAgregar.clear()
            self.IngresarGastoMaterialesEgresoAgregar_2.clear()
            self.IngresarGastoEmpaqueEgresoAgregar.clear()

        except ValueError:
            QMessageBox.warning(self, "Error", "Los gastos deben ser números válidos.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def modificar(self):
        EgresoID = self.Ingresar_ID_Egreso_Mod.text().strip()

        if not EgresoID:
            QMessageBox.warning(self, "Advertencia", "Debes ingresar el ID del egreso.")
            return
        if not EgresoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El ID del egreso contiene carácteres no numéricos.")
            return

        try:
            cursor = self.connection.cursor()

            # Obtener los valores actuales
            cursor.execute("SELECT PedidoID, GastoEnvio, GastoMateriales, GastoEmpaque, FechaEgreso FROM Egreso WHERE EgresoID = %s", (int(EgresoID),))
            resultado = cursor.fetchone()

            if resultado is None:
                QMessageBox.warning(self, "Advertencia", "No existe un egreso con ese ID.")
                return

            pedido_actual, envio_actual, materiales_actual, empaque_actual, fecha_actual = resultado

            # Obtener nuevos datos (si no hay input, usar el actual)
            nuevo_pedido = self.Ingresar_ID_Pedido_Egreso_Mod.text().strip()
            nuevo_envio = self.Ingresar_Gasto_Envio_Egreso_Mod.text().strip()
            nuevo_materiales = self.Ingresar_Gasto_Mat_Egreso_Mod.text().strip()
            nuevo_empaque = self.Ingresar_Gasto_Empaque_Egreso_Mod.text().strip()
            nueva_fecha = self.Ingresar_Fecha_Egreso_Mod.text().strip()

            # Reemplazar vacíos por valores actuales
            PedidoID = int(nuevo_pedido) if nuevo_pedido else pedido_actual
            GastoEnvio = float(nuevo_envio) if nuevo_envio else float(envio_actual)
            GastoMateriales = float(nuevo_materiales) if nuevo_materiales else float(materiales_actual)
            GastoEmpaque = float(nuevo_empaque) if nuevo_empaque else float(empaque_actual)
            FechaEgreso = nueva_fecha if nueva_fecha else fecha_actual.strftime('%Y-%m-%d')

            # Verificar que el PedidoID exista en la tabla Pedido
            cursor.execute("SELECT * FROM Pedido WHERE PedidoID = %s", (PedidoID,))
            pedido_valido = cursor.fetchone()
            if not pedido_valido:
                QMessageBox.warning(self, "Advertencia", f"No existe un Pedido con ID {PedidoID}.")
                return

            # Ejecutar actualización
            cursor.execute("""
                UPDATE Egreso SET
                    PedidoID = %s,
                    GastoEnvio = %s,
                    GastoMateriales = %s,
                    GastoEmpaque = %s,
                    FechaEgreso = %s
                WHERE EgresoID = %s
            """, (
                PedidoID,
                GastoEnvio,
                GastoMateriales,
                GastoEmpaque,
                FechaEgreso,
                int(EgresoID)
                ))

            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Registro modificado correctamente.")
            self.visualizar_tabla()

            # Limpiar campos
            self.Ingresar_ID_Egreso_Mod.clear()
            self.Ingresar_ID_Pedido_Egreso_Mod.clear()
            self.Ingresar_Gasto_Envio_Egreso_Mod.clear()
            self.Ingresar_Gasto_Mat_Egreso_Mod.clear()
            self.Ingresar_Gasto_Empaque_Egreso_Mod.clear()
            self.Ingresar_Fecha_Egreso_Mod.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


        

        
    def eliminar(self):
        EgresoID = self.Ingresar_ID_Egreso_Eliminar.text()
        if not EgresoID.isdigit():
            QMessageBox.warning(self, "Advertencia", "El EgresoID ingresado contiene carácteres no numéricos.")
            return

        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM EGRESO WHERE EgresoID = %s", (int(EgresoID),))
            existe = cursor.fetchone()
            if not existe:
                QMessageBox.warning(self, "Advertencia", "No se encontró el EgresoID.")
                return

            confirm = QMessageBox.question(
                self, "Confirmar eliminación",
                f"¿Estás seguro de eliminar el DetallePedido {EgresoID}?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes:
                return

            cursor.execute("DELETE FROM EGRESO WHERE EgresoID = %s", (int(EgresoID),))
            self.connection.commit()
            QMessageBox.information(self, "Éxito", "Egreso eliminado.")
            self.visualizar_tabla()
            self.Ingresar_ID_Egreso_Eliminar.clear()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def cerrar_sesion(self):
        from Ingreso_MFEC import MainWindow
        confirm = QMessageBox.question(self, "Cerrar sesión", "¿Cerrar sesión?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.login_window = MainWindow()
            self.login_window.show()
            self.close()


    def volver_menu_CRUD(self):
        from Operaciones_CRUD.Menu_CRUD import MenuCRUD
        self.menu_principal = MenuCRUD(self.connection)  
        self.menu_principal.show()  
        self.hide() 